
/* 
  * File: FacePamphlet.java
 * -----------------------
 * When it is finished, this program will implement a basic social network
 * management system.
 */

import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.event.*;
import java.util.Iterator;

import javax.swing.*;

public class FacePamphlet extends Program implements FacePamphletConstants {

	private JTextField nameField;
	private JButton add;
	private JButton delete;
	private JButton lookUp;
	private JTextField statusField;
	private JTextField pictureField;
	private JTextField friendField;
	private JButton statusButton;
	private JButton pictureButton;
	private JButton friendButton;
	private FacePamphletCanvas canvas;
	FacePamphletDatabase data;
	FacePamphletProfile currentProfile;

	/**
	 * This method has the responsibility for initializing the interactors in
	 * the application, and taking care of any other initialization that needs
	 * to be performed.
	 */
	public void init() {
		data = new FacePamphletDatabase();
		canvas = new FacePamphletCanvas();
		add(canvas);
		createInteractors();
		addInteractors();
		actionListeners();
		addActionListeners(this);
	}

	// creates interactors for the application
	private void createInteractors() {
		createTopInteractors();
		createLeftInteractors();
	}

	// creates interactors on top of the window
	private void createTopInteractors() {
		nameField = new JTextField(TEXT_FIELD_SIZE);
		add = new JButton("Add");
		delete = new JButton("Delete");
		lookUp = new JButton("LookUp");
	}

	// creates interactors on left side of the window
	private void createLeftInteractors() {
		statusField = new JTextField(TEXT_FIELD_SIZE);
		statusButton = new JButton("Change Status");

		pictureField = new JTextField(TEXT_FIELD_SIZE);
		pictureButton = new JButton("Change Picture");

		friendField = new JTextField(TEXT_FIELD_SIZE);
		friendButton = new JButton("Add Friend");
	}

	// Adds interactors on the window
	private void addInteractors() {
		addTopInteractors();
		addLeftInteractors();
	}

	// adds Interactors on left side of the window.
	private void addLeftInteractors() {
		add(statusField, WEST);
		add(statusButton, WEST);

		add(new JLabel(EMPTY_LABEL_TEXT), WEST);

		add(pictureField, WEST);
		add(pictureButton, WEST);

		add(new JLabel(EMPTY_LABEL_TEXT), WEST);

		add(friendField, WEST);
		add(friendButton, WEST);

	}

	// adds interactors at top of the window
	private void addTopInteractors() {
		add(new JLabel("name"), NORTH);
		add(nameField, NORTH);
		add(add, NORTH);
		add(delete, NORTH);
		add(lookUp, NORTH);
	}

	// adds action listeners for interactors
	private void actionListeners() {
		topActionListeners();
		leftActionListeners();
	}

	// adds action listeners for interactors that are on the left side of the
	// window.
	private void leftActionListeners() {
		statusField.addActionListener(this);
		statusButton.addActionListener(this);

		pictureField.addActionListener(this);
		pictureButton.addActionListener(this);

		friendField.addActionListener(this);
		friendButton.addActionListener(this);

	}

	// adds action listeners for interactors that are on the left side of the
	// window
	private void topActionListeners() {
		add.addActionListener(this);
		delete.addActionListener(this);
		lookUp.addActionListener(this);

	}

	/**
	 * This class is responsible for detecting when the buttons are clicked or
	 * interactors are used
	 */
	public void actionPerformed(ActionEvent e) {
		String name = nameField.getText();
		topActions(e, name);
		leftActions(e, name);
	}

	// handles actions of ineractors on the left side of the window.
	private void leftActions(ActionEvent e, String name) {

		statusSection(e);
		imageSection(e);
		friendsSection(e);
	}

	// handles adding image of the profile.
	private void imageSection(ActionEvent e) {
		if (e.getSource() == pictureButton || e.getSource() == pictureField) {
			if (!pictureField.getText().replaceAll(" ", "").isEmpty()) {
				if (currentProfile != null) {
					checkImage();
					pictureField.setText("");
				} else {
					canvas.showMessage("Please select a profile to change profile Picture");
				}
			}
		}

	}

	// Checks whether the given image is of a correct format, acts accordingly
	// and prints appropriate messages.
	private void checkImage() {
		GImage image = null;
		try {
			image = new GImage(pictureField.getText());
			if (currentProfile != null) {
				currentProfile.setImage(image);
				canvas.displayProfile(currentProfile);
				canvas.showMessage("Picture updated");
			}
		} catch (ErrorException ex) {
			canvas.showMessage("Unable to open image file: " + pictureField.getText());
		}
	}

	// handles status section of the profile.
	private void statusSection(ActionEvent e) {
		if (e.getSource() == statusButton || e.getSource() == statusField) {
			if (!statusField.getText().replaceAll(" ", "").isEmpty()) {
				changeStatus();
			}
		}
	}

	// Changes status of the profile appropriately.
	private void changeStatus() {
		if (currentProfile != null) {
			currentProfile.setStatus(statusField.getText());
			canvas.displayProfile(currentProfile);
			canvas.showMessage("Status updated to " + statusField.getText());
			statusField.setText("");
		} else {
			canvas.showMessage("Please select a profile to change status");
			statusField.setText("");
		}
	}

	// handles friends section of the profile
	private void friendsSection(ActionEvent e) {
		if (e.getSource() == friendButton || e.getSource() == friendField) {
			if (!friendField.getText().replaceAll(" ", "").isEmpty()) {
				addFriend();
				friendField.setText("");
			}
		}

	}

	// adds given friend to the list of friends of the profile. forbids adding
	// yourself as a friend or adding nonexistant profile. It also checks
	// whether or not current profile exists
	private void addFriend() {
		String friendName = friendField.getText();
		if (currentProfile != null) {
			if (friendName.equals(currentProfile.getName())) {
				canvas.showMessage("You can't add yourself as a friend");
			} else if (data.containsProfile(friendName)) {
				addToFriendsList(friendName);
			} else if (currentProfile != null) {
				canvas.showMessage("Profile with name \"" + friendName + "\" doesn't exist");
			}
		} else {
			canvas.showMessage("Please select a profile to add friends");
			friendField.setText("");
		}
	}

	// Adds given friend to the list of friends of the profile, after checking
	// whether or not given profile is in the friends list
	private void addToFriendsList(String friendName) {
		if (listHasFriend(friendName)) {
			canvas.showMessage("You are already friends with " + friendName);
		} else {
			currentProfile.addFriend(friendName);
			data.getProfile(friendName).addFriend(currentProfile.getName());
			canvas.displayProfile(currentProfile);
			canvas.showMessage(friendName + " added as a frind");

		}
	}

	// Checks whether friend list of given profile contains given friend name.
	private boolean listHasFriend(String friendName) {
		Iterator<String> friendList = currentProfile.getFriends();
		while (friendList.hasNext()) {
			if (friendList.next().equals(friendName)) {
				return true;
			}
		}
		return false;
	}

	// Handles interactors of the top side of the window.
	private void topActions(ActionEvent e, String name) {
		String exceptionCheck = name.replaceAll(" ", "");
		if (!exceptionCheck.isEmpty()) {

			addProfile(name, e);

			deleteProfile(name, e);

			lookUpProfile(name, e);

			nameField.setText("");
		}
	}

	// handles lookup section of the program. checks whether given profile
	// exists, acts accordingly and prints appropriate messages.
	private void lookUpProfile(String name, ActionEvent e) {
		if (e.getSource() == lookUp) {
			if (data.containsProfile(name)) {
				currentProfile = data.getProfile(name);
				canvas.displayProfile(currentProfile);
				canvas.showMessage("Displaying " + name);
			} else {
				canvas.removeAll();
				canvas.showMessage("A profile with the name " + name + " doesn't exist");
				currentProfile = null;
			}
		}

	}

	// Deletes given profile if the profile exists and prints appropriate
	// messages.
	private void deleteProfile(String name, ActionEvent e) {
		if (e.getSource() == delete) {
			if (data.getProfile(name) != null) {
				data.deleteProfile(name);
				canvas.removeAll();
				canvas.showMessage("Profile of " + name + " deleted");
				currentProfile = null;
			} else {
				canvas.removeAll();
				canvas.showMessage("profile with name " + name + " doesn't exist");
			}

		}

	}

	// Adds new profile to the database and displays it on the screen. If given
	// name already corresponds to the old profile displays old profile and
	// prints appropriate messages
	private void addProfile(String name, ActionEvent e) {
		if (e.getSource() == add) {
			if (data.containsProfile(name)) {
				canvas.displayProfile(data.getProfile(name));
				canvas.showMessage("A profile with the name " + name + " already exists");
			} else {
				createNewProfile(name);
			}
		}
	}

	// creates New profile with a given name.
	private void createNewProfile(String name) {
		currentProfile = new FacePamphletProfile(name);
		data.addProfile(currentProfile);
		currentProfile = data.getProfile(name);
		canvas.displayProfile(data.getProfile(name));
		canvas.showMessage("New profile created");
	}

}
