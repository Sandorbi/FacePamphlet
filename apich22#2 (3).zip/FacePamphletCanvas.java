
/*
 * File: FacePamphletCanvas.java
 * -----------------------------
 * This class represents the canvas on which the profiles in the social
 * network are displayed.  NOTE: This class does NOT need to update the
 * display when the window is resized.
 */

import acm.graphics.*;
import java.awt.*;
import java.util.*;

public class FacePamphletCanvas extends GCanvas implements FacePamphletConstants {

	private GLabel nameLabel;
	private GRect imgRect;
	private GLabel messageLabel = new GLabel("");

	/**
	 * Constructor This method takes care of any initialization needed for the
	 * display
	 */
	public FacePamphletCanvas() {

	}

	/**
	 * This method displays a message string near the bottom of the canvas.
	 * Every time this method is called, the previously displayed message (if
	 * any) is replaced by the new message text passed in.
	 */
	public void showMessage(String msg) {
		remove(messageLabel);
		messageLabel.setLabel(msg);
		messageLabel.setFont(MESSAGE_FONT);
		add(messageLabel, getWidth() / 2 - messageLabel.getWidth() / 2, getHeight() - BOTTOM_MESSAGE_MARGIN);
	}

	/**
	 * This method displays the given profile on the canvas. The canvas is first
	 * cleared of all existing items (including messages displayed near the
	 * bottom of the screen) and then the given profile is displayed. The
	 * profile display includes the name of the user from the profile, the
	 * corresponding image (or an indication that an image does not exist), the
	 * status of the user, and a list of the user's friends in the social
	 * network.
	 */
	public void displayProfile(FacePamphletProfile profile) {
		removeAll();
		displayName(profile.getName());
		displayImage(profile);
		displayStatus(profile);
		displayFriends(profile);
	}

	// This method displays the status of the profile.
	private void displayStatus(FacePamphletProfile profile) {
		GLabel statusLabel = new GLabel("No Current status");
		add(statusLabel, LEFT_MARGIN, imgRect.getY() + imgRect.getHeight() + STATUS_MARGIN);
		statusLabel.setFont(PROFILE_STATUS_FONT);
		if (!profile.getStatus().isEmpty()) {
			statusLabel.setLabel(profile.getName() + " is " + profile.getStatus());
		}

	}

	// This method displays image of the profile.
	private void displayImage(FacePamphletProfile profile) {
		imgRect = new GRect(LEFT_MARGIN, TOP_MARGIN + nameLabel.getHeight() + IMAGE_MARGIN, IMAGE_WIDTH, IMAGE_HEIGHT);
		if (profile.getImage() == null) {
			addRect();
		} else {
			addImage(profile);
		}

	}

	// This method adds the image on the screen
	private void addImage(FacePamphletProfile profile) {
		GImage image = profile.getImage();
		add(image, imgRect.getX(), imgRect.getY());
		image.setSize(IMAGE_WIDTH, IMAGE_HEIGHT);

	}

	// This method adds rectangle if the image doesn't exist for the given
	// profile.
	private void addRect() {
		add(imgRect);
		GLabel label = new GLabel("No Image");
		add(label, imgRect.getX() + imgRect.getWidth() / 2 - label.getWidth(),
				imgRect.getY() + imgRect.getHeight() / 2 + label.getHeight() / 2);
		label.setFont(PROFILE_IMAGE_FONT);

	}

	// this method displays name of the profile.
	private void displayName(String name) {
		nameLabel = new GLabel(name);
		add(nameLabel, LEFT_MARGIN, TOP_MARGIN + nameLabel.getHeight());
		nameLabel.setFont(PROFILE_NAME_FONT);
		nameLabel.setColor(Color.BLUE);
	}

	// This method displays friends list of the profile.
	private void displayFriends(FacePamphletProfile profile) {
		Iterator<String> friendsIterator = profile.getFriends();

		GLabel label = new GLabel("Friends:");
		add(label, getWidth() / 2, imgRect.getY() + label.getHeight());
		label.setFont(PROFILE_FRIEND_LABEL_FONT);

		showList(friendsIterator, label);
	}

	// This method adds list of friends under friends section.
	private void showList(Iterator<String> friendsIterator, GLabel label) {
		int i = 20;
		while (friendsIterator.hasNext()) {
			GLabel friendsLabel = new GLabel("");
			friendsLabel.setLabel(friendsIterator.next());
			friendsLabel.setFont(PROFILE_FRIEND_FONT);
			add(friendsLabel, label.getX(), label.getY() + i);
			i += 20;
		}

	}

}
